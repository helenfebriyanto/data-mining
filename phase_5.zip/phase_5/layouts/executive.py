from dash import html

def executive_layout(DATA, FIGURES):

    return html.Div([
        html.H2("Executive Summary")
    ])